package com.example.myapplication;

import com.adobe.marketing.mobile.AdobeCallback;
import com.adobe.marketing.mobile.AdobeCallbackWithError;
import com.adobe.marketing.mobile.AdobeError;
import com.adobe.marketing.mobile.Analytics;
import com.adobe.marketing.mobile.Extension;
import com.adobe.marketing.mobile.Identity;
import com.adobe.marketing.mobile.Lifecycle;
import com.adobe.marketing.mobile.LoggingMode;
import com.adobe.marketing.mobile.MobileCore;
import com.adobe.marketing.mobile.MobilePrivacyStatus;
import com.adobe.marketing.mobile.Signal;
import com.adobe.marketing.mobile.UserProfile;

import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.app.Application;
import android.util.Log;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        MobileCore.setApplication(this);
        MobileCore.setLogLevel(LoggingMode.DEBUG);

        List<Class<? extends Extension>> extensions = Arrays.asList(
                Analytics.EXTENSION,
                UserProfile.EXTENSION,
                Identity.EXTENSION,
                Lifecycle.EXTENSION,
                Signal.EXTENSION
        );

        MobileCore.registerExtensions(extensions, new AdobeCallback() {
            @Override
            public void call(Object o) {
                MobileCore.configureWithAppID("22baa8e94be8/03cdec9856a6/launch-3ea95b365868-development");
            }
        });

    }

}
